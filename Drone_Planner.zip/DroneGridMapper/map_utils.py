import folium
from folium.plugins import Draw
from shapely.geometry import Polygon, Point
import numpy as np
import requests
import streamlit as st

def create_map(center=[0.0, 0.0], zoom=10):
    """Create a Folium map with drawing controls and a search bar for location input."""
    m = folium.Map(location=center, zoom_start=zoom)

    # Add drawing controls
    draw = Draw(draw_options={
        'polyline': False,
        'rectangle': True,
        'polygon': True,
        'circle': True,
        'marker': False,
        'circlemarker': False
    },
                edit_options={'edit': False})
    m.add_child(draw)

    return m

def geocode_location(search_query):
    """Use a geocoding API to convert a location name into coordinates."""
    api_url = f"https://nominatim.openstreetmap.org/search?q={search_query}&format=json"
    response = requests.get(api_url)
    if response.status_code == 200 and response.json():
        location_data = response.json()[0]
        return float(location_data["lat"]), float(location_data["lon"])
    return None, None

def calculate_area_bounds(geometry):
    """Calculate the bounds, center point, area, and shape of the drawn AOI."""
    if not geometry:
        return {"error": "No geometry provided"}

    try:
        if geometry['type'] in ['Polygon', 'MultiPolygon']:
            coords = geometry['coordinates'][0] if geometry['type'] == 'Polygon' else geometry['coordinates'][0][0]
            lats = [coord[1] for coord in coords]
            lons = [coord[0] for coord in coords]

            if not lats or not lons:
                return {"error": "Invalid polygon coordinates"}

            center_lat = np.mean(lats)
            center_lon = np.mean(lons)
            width = (max(lons) - min(lons)) * 111139  # Convert degrees to meters
            height = (max(lats) - min(lats)) * 111139  # Convert degrees to meters
            area_meters = width * height
            area_feet = area_meters * 10.764  # Convert meters to square feet

            return {
                "width": width,
                "height": height,
                "center_lat": center_lat,
                "center_lon": center_lon,
                "area_meters": area_meters,
                "area_feet": area_feet,
                "shape": "Polygon"
            }

        elif geometry['type'] == 'Point':  # Handling circle AOI
            lat, lon = geometry['coordinates']
            return {
                "width": 0,
                "height": 0,
                "center_lat": lat,
                "center_lon": lon,
                "area_meters": 0,
                "area_feet": 0,
                "shape": "Circle"
            }

        elif geometry['type'] == 'Circle':  # Handling drawn circles
            center = geometry['coordinates']
            radius = geometry.get('radius', 0)
            area_meters = np.pi * (radius ** 2)
            area_feet = area_meters * 10.764
            return {
                "width": radius * 2,
                "height": radius * 2,
                "center_lat": center[1],
                "center_lon": center[0],
                "area_meters": area_meters,
                "area_feet": area_feet,
                "shape": "Circle"
            }

        return {"error": f"Unsupported geometry type: {geometry['type']}"}

    except Exception as e:
        return {
            "width": 0.0,
            "height": 0.0,
            "center_lat": 0.0,
            "center_lon": 0.0,
            "area_meters": 0.0,
            "area_feet": 0.0,
            "shape": "Error",
            "error": f"Failed to process geometry: {str(e)}"
        }

def generate_flight_grid(area_bounds, waypoint_spacing, camera_interval, actions=None):
    """Generate a grid of waypoints within the AOI, ensuring correct geographic placement."""
    if not area_bounds or 'center_lat' not in area_bounds or 'center_lon' not in area_bounds:
        return []

    waypoints = []
    lat_start = area_bounds['center_lat'] - (area_bounds['height'] / 2) / 111139
    lon_start = area_bounds['center_lon'] - (area_bounds['width'] / 2) / (111139 * np.cos(np.radians(area_bounds['center_lat'])))

    num_rows = int(area_bounds['height'] / waypoint_spacing)
    num_cols = int(area_bounds['width'] / waypoint_spacing)

    for i in range(num_rows + 1):
        for j in range(num_cols + 1):
            waypoint = {
                "longitude": lon_start + (j * waypoint_spacing) / (111139 * np.cos(np.radians(area_bounds['center_lat']))),
                "latitude": lat_start + (i * waypoint_spacing) / 111139,
                "actions": []
            }

            if actions:
                if "Take Picture" in actions:
                    waypoint["actions"].append("Take Picture")
                if "Start Recording" in actions:
                    waypoint["actions"].append("Start Recording")
                if "Stop Recording" in actions:
                    waypoint["actions"].append("Stop Recording")

            waypoints.append(waypoint)
    import folium
    from folium.plugins import Draw
    from shapely.geometry import Polygon, Point
    import numpy as np
    import requests
    import streamlit as st

    def create_map(center=[0.0, 0.0], zoom=10):
        """Create a Folium map with drawing controls and a search bar for location input."""
        m = folium.Map(location=center, zoom_start=zoom)

        # Add drawing controls
        draw = Draw(draw_options={
            'polyline': False,
            'rectangle': True,
            'polygon': True,
            'circle': True,
            'marker': False,
            'circlemarker': False
        },
                    edit_options={'edit': False})
        m.add_child(draw)

        return m

    def geocode_location(search_query):
        """Use a geocoding API to convert a location name into coordinates."""
        api_url = f"https://nominatim.openstreetmap.org/search?q={search_query}&format=json"
        response = requests.get(api_url)
        if response.status_code == 200 and response.json():
            location_data = response.json()[0]
            return float(location_data["lat"]), float(location_data["lon"])
        return None, None

    def calculate_area_bounds(geometry):
        """Calculate the bounds, center point, area, and shape of the drawn AOI."""
        if not geometry:
            return {"error": "No geometry provided"}

        try:
            if geometry['type'] in ['Polygon', 'MultiPolygon']:
                coords = geometry['coordinates'][0] if geometry['type'] == 'Polygon' else geometry['coordinates'][0][0]
                lats = [coord[1] for coord in coords]
                lons = [coord[0] for coord in coords]

                if not lats or not lons:
                    return {"error": "Invalid polygon coordinates"}

                center_lat = np.mean(lats)
                center_lon = np.mean(lons)
                width = (max(lons) - min(lons)) * 111139  # Convert degrees to meters
                height = (max(lats) - min(lats)) * 111139  # Convert degrees to meters
                area_meters = width * height
                area_feet = area_meters * 10.764  # Convert meters to square feet

                return {
                    "width": width,
                    "height": height,
                    "center_lat": center_lat,
                    "center_lon": center_lon,
                    "area_meters": area_meters,
                    "area_feet": area_feet,
                    "shape": "Polygon"
                }

            elif geometry['type'] == 'Point':  # Handling circle AOI
                lat, lon = geometry['coordinates']
                return {
                    "width": 0,
                    "height": 0,
                    "center_lat": lat,
                    "center_lon": lon,
                    "area_meters": 0,
                    "area_feet": 0,
                    "shape": "Circle"
                }

            elif geometry['type'] == 'Circle':  # Handling drawn circles
                center = geometry['coordinates']
                radius = geometry.get('radius', 0)
                area_meters = np.pi * (radius ** 2)
                area_feet = area_meters * 10.764
                return {
                    "width": radius * 2,
                    "height": radius * 2,
                    "center_lat": center[1],
                    "center_lon": center[0],
                    "area_meters": area_meters,
                    "area_feet": area_feet,
                    "shape": "Circle"
                }

            return {"error": f"Unsupported geometry type: {geometry['type']}"}

        except Exception as e:
            return {
                "width": 0.0,
                "height": 0.0,
                "center_lat": 0.0,
                "center_lon": 0.0,
                "area_meters": 0.0,
                "area_feet": 0.0,
                "shape": "Error",
                "error": f"Failed to process geometry: {str(e)}"
            }

    def generate_flight_grid(area_bounds, waypoint_spacing, camera_interval, actions=None):
        """Generate a grid of waypoints within the AOI, ensuring correct geographic placement."""
        if not area_bounds or 'center_lat' not in area_bounds or 'center_lon' not in area_bounds:
            return []

        waypoints = []
        lat_start = area_bounds['center_lat'] - (area_bounds['height'] / 2) / 111139
        lon_start = area_bounds['center_lon'] - (area_bounds['width'] / 2) / (111139 * np.cos(np.radians(area_bounds['center_lat'])))

        num_rows = int(area_bounds['height'] / waypoint_spacing)
        num_cols = int(area_bounds['width'] / waypoint_spacing)

        for i in range(num_rows + 1):
            for j in range(num_cols + 1):
                waypoint = {
                    "longitude": lon_start + (j * waypoint_spacing) / (111139 * np.cos(np.radians(area_bounds['center_lat']))),
                    "latitude": lat_start + (i * waypoint_spacing) / 111139,
                    "actions": []
                }

                if actions:
                    if "Take Picture" in actions:
                        waypoint["actions"].append("Take Picture")
                    if "Start Recording" in actions:
                        waypoint["actions"].append("Start Recording")
                    if "Stop Recording" in actions:
                        waypoint["actions"].append("Stop Recording")

                waypoints.append(waypoint)

        return waypoints

    def estimate_flight_time(waypoints, speed):
        """Estimate total flight time based on waypoint distances and UAV speed."""
        if not waypoints or speed <= 0:
            return 0.0

        total_distance = (len(waypoints) - 1) * 10  # Approximate distance in meters
        estimated_time = total_distance / speed  # Time in seconds
        return estimated_time / 60  # Convert to minutes

    def display_estimated_flight_time(waypoints, speed):
        """Displays estimated flight time before download options."""
        flight_time = estimate_flight_time(waypoints, speed)
        st.write(f"**Estimated Flight Time:** {flight_time:.2f} minutes")

    def adjust_path_to_boundary(path_coords, boundary_shape):
        """Adjust flight path coordinates to stay within the boundary."""
        if not path_coords:
            return []
        return path_coords  # For now, return all coordinates

    return waypoints

def estimate_flight_time(waypoints, speed):
    """Estimate total flight time based on waypoint distances and UAV speed."""
    if not waypoints or speed <= 0:
        return 0.0

    total_distance = (len(waypoints) - 1) * 10  # Approximate distance in meters
    estimated_time = total_distance / speed  # Time in seconds
    return estimated_time / 60  # Convert to minutes

def adjust_path_to_boundary(path_coords, boundary_shape):
    """Adjust flight path coordinates to stay within the boundary."""
    if not path_coords:
        return []
    return path_coords  # For now, return all coordinates
