import numpy as np
from math import tan, radians

def calculate_ground_coverage(altitude, fov):
    """Calculate the ground coverage width based on altitude and field of view"""
    width = 2 * altitude * tan(radians(fov/2))
    return width

def generate_grid_path(area_width, area_height, overlap, sidelap, altitude, speed, interval, fov):
    """Generate grid path coordinates based on input parameters"""
    print(f"Generating grid path with: width={area_width}, height={area_height}")  # Debug log

    # For testing, generate a simple grid pattern
    x_points = np.linspace(-area_width/2, area_width/2, 5)
    y_points = np.linspace(-area_height/2, area_height/2, 5)

    path_coords = []
    for i, x in enumerate(x_points):
        if i % 2 == 0:
            # Forward direction
            for y in y_points:
                path_coords.append((x, y))
        else:
            # Reverse direction
            for y in y_points[::-1]:
                path_coords.append((x, y))

    print(f"Generated {len(path_coords)} waypoints")  # Debug log
    return path_coords

def validate_parameters(params, drone_specs):
    """Validate flight parameters against drone specifications"""
    errors = []

    if params['altitude'] < drone_specs['min_altitude']:
        errors.append(f"Altitude must be at least {drone_specs['min_altitude']}m")
    if params['altitude'] > drone_specs['max_altitude']:
        errors.append(f"Altitude cannot exceed {drone_specs['max_altitude']}m")

    if params['speed'] > drone_specs['max_speed']:
        errors.append(f"Speed cannot exceed {drone_specs['max_speed']}m/s")

    if params['interval'] < drone_specs['min_interval']:
        errors.append(f"Interval cannot be less than {drone_specs['min_interval']}s")

    if not (0 <= params['overlap'] <= 95):
        errors.append("Overlap must be between 0% and 95%")

    if not (0 <= params['sidelap'] <= 95):
        errors.append("Sidelap must be between 0% and 95%")

    return errors