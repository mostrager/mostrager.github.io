import streamlit as st
import numpy as np
import pandas as pd
import folium
from drone_specs import DRONE_SPECS
from flight_calculator import generate_grid_path, validate_parameters
from utils import create_flight_path_plot
from map_utils import create_map, calculate_area_bounds
from streamlit_folium import st_folium
from dji_export import create_kml_file
import simplekml  # Import for KMZ export
import io  # Required for in-memory file downloads


def main():
    st.set_page_config(page_title="UAV Flight Path Planner", layout="wide")

    st.title("UAV Flight Path Planner")
    st.markdown("""
    Plan your drone's flight path with customized parameters for optimal area coverage.
    1. Draw your area of interest on the map
    2. Set your flight parameters
    3. Click 'Generate Flight Plan' to create the path
    """)

    # Initialize session state for flight path and AOI
    if 'flight_path' not in st.session_state:
        st.session_state.flight_path = None
    if 'area_bounds' not in st.session_state:
        st.session_state.area_bounds = None

    # Create columns for map and parameters
    col1, col2 = st.columns([2, 1])

    with col1:
        # Capture drawn AOI from map interaction
        map_data = st_folium(create_map(), width=700, height=500)

        # Ensure AOI is stored and not reset
        if map_data and 'last_active_drawing' in map_data:
            geometry = map_data['last_active_drawing']
            if geometry and geometry.get(
                    'geometry'):  # Ensure valid geometry is retrieved
                st.session_state.area_bounds = calculate_area_bounds(
                    geometry['geometry'])

                # 🔍 Debugging Output
                st.write("🔍 AOI Data:", st.session_state.area_bounds)

                if st.session_state.area_bounds:
                    st.success(
                        f"✅ AOI Captured - Center: ({st.session_state.area_bounds['center_lat']}, {st.session_state.area_bounds['center_lon']})"
                    )
                else:
                    st.error(
                        "❌ AOI calculation failed. No valid data returned.")

    with col2:
        st.subheader("Flight Parameters")
        overlap = st.slider("Front Overlap (%)",
                            min_value=0.0,
                            max_value=1.0,
                            value=0.8)
        sidelap = st.slider("Side Overlap (%)",
                            min_value=0.0,
                            max_value=1.0,
                            value=0.7)
        altitude = st.number_input("Altitude (m)", min_value=1, value=50)
        speed = st.number_input("Speed (m/s)", min_value=1, value=5)
        interval = st.number_input("Camera Interval (s)", min_value=1, value=2)
        fov = st.number_input("Camera Field of View (°)",
                              min_value=10,
                              value=85)

        # Check if AOI exists before generating
        if st.button("Generate Flight Plan"):
            if st.session_state.area_bounds:
                # Generate flight plan
                st.session_state.flight_path = generate_grid_path(
                    area_width=st.session_state.area_bounds['width'],
                    area_height=st.session_state.area_bounds['height'],
                    overlap=overlap,
                    sidelap=sidelap,
                    altitude=altitude,
                    speed=speed,
                    interval=interval,
                    fov=fov)
                st.success("Flight plan generated successfully!")

    # Display the flight plan on the map
    if st.session_state.flight_path:
        st.subheader("Generated Flight Plan")

        # Create a new map centered at the AOI
        flight_map = folium.Map(location=[
            st.session_state.area_bounds['center_lat'],
            st.session_state.area_bounds['center_lon']
        ],
                                zoom_start=15)

        # Add flight path to the map
        for coord in st.session_state.flight_path:
            folium.Marker(location=[coord[1], coord[0]],
                          popup=f"Waypoint: {coord}").add_to(flight_map)

        # Display the updated map
        st_folium(flight_map, width=700, height=500)

        # Convert flight plan to DataFrame for downloading
        df_flight_plan = pd.DataFrame(st.session_state.flight_path,
                                      columns=["Longitude", "Latitude"])

        # Create CSV download button
        st.download_button(label="Download Flight Plan (CSV)",
                           data=df_flight_plan.to_csv(index=False),
                           file_name="flight_plan.csv",
                           mime="text/csv")

        # Generate KMZ file
        kml = simplekml.Kml()
        for coord in st.session_state.flight_path:
            kml.newpoint(name="Waypoint",
                         coords=[(coord[0], coord[1])])  # Longitude, Latitude

        kmz_data = io.BytesIO()
        kml_str = kml.kml()  # Get the KML data as a string
        kmz_data.write(kml_str.encode('utf-8'))  # Write encoded KML data
        kmz_data.seek(0)

        # Create KMZ download button
        st.download_button(label="Download Flight Plan (KMZ)",
                           data=kmz_data,
                           file_name="flight_plan.kmz",
                           mime="application/vnd.google-earth.kmz")


if __name__ == "__main__":
    main()
